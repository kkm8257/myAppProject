package com.example.movie_app_2;

public class itemClass {
    int rank;
    String title="";
    String count="";
    String total_count="";

    public itemClass(int rank,String title, String count, String total_count) {

        this.rank = rank+1;
        this.title = title;
        this.count = count;
        this.total_count = total_count;

    }



}

package com.example.movie_app_2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    public MyAdapter myAdt;
    public static Intent mvInfoIntent;

    ProgressBar pgBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pgBar = findViewById(R.id.pg_bar);


        Storage.click_btn = findViewById(R.id.click_btn);
        Storage.click_btn.setOnClickListener(this);
        mvInfoIntent = new Intent(this, com.example.movie_app_2.movie_info_frame.class);
        Storage.year_txt_main = findViewById(R.id.year_text);
        Storage.month_txt_main = findViewById(R.id.month_text);
        Storage.date_txt_main = findViewById(R.id.date_text);

        Storage.listView = findViewById(R.id.list_view);

        myAdt = new MyAdapter(this);
        Storage.listView.setAdapter(myAdt);

        Storage.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Storage.position = i;
                startActivity(mvInfoIntent);

            }
        });


    }

    public static boolean isNumeric(String s) {
        try {
            Double.parseDouble(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isRightNum_year(String s) {
        if (Integer.parseInt(s) > 2009 && Integer.parseInt(s) <= 2020) {
            return true;
        } else {
//            Toast.makeText(this, "날짜를 다시 입력해주세요.", Toast.LENGTH_SHORT).show();

            return false;

        }
    }

    public static boolean isRightNum_month(String s) {


        if (s.substring(0, 1).equals("0")) {

            Log.d("aabb", "입력에러");
        }
        else if (Integer.parseInt(s) >= 1 && Integer.parseInt(s) <= 12) {

            return true;
        } else {
            return false;
        }
        return false;
    }

    public static boolean isRightNum_date(String m, String d) {

        if (d.substring(0, 1).equals("0")) {

            Log.d("aabb", "입력에러");
        } else if (Integer.parseInt(m) == 1 || Integer.parseInt(m) == 3 || Integer.parseInt(m) == 5 || Integer.parseInt(m) == 7 || Integer.parseInt(m) == 8 || Integer.parseInt(m) == 10 || Integer.parseInt(m) == 12) {
            //31일

            if (Integer.parseInt(d) <= 31 && Integer.parseInt(d) >= 1) {
                return true;
            } else {
                return false;
            }
        } else if (Integer.parseInt(m) == 2 || Integer.parseInt(m) == 4 || Integer.parseInt(m) == 6 || Integer.parseInt(m) == 9 || Integer.parseInt(m) == 11) {
            //30일

//            Log.d("aabb", d);
            if (Integer.parseInt(d) <= 30 && Integer.parseInt(d) >= 1) {
                return true;
            } else {
                return false;
            }

        } else {
            return false;

        }
        return false;

    }

    @Override
    public void onClick(View view) {


        Storage.year = Storage.year_txt_main.getText().toString();
        Storage.month = Storage.month_txt_main.getText().toString();
        Storage.date = Storage.date_txt_main.getText().toString();

        if (isNumeric(Storage.year) == false || isNumeric(Storage.month) == false || isNumeric(Storage.date) == false) {
            //숫자가 아닌 문자열
            Log.d("aabb", "숫자가아닌 문자열 입력");

        } else {
            if (isRightNum_year(Storage.year) && isRightNum_month(Storage.month) && isRightNum_date(Storage.month, Storage.date)) {


                pgBar.setVisibility(View.VISIBLE);
                myAdt.clear();
                Storage.mvCodeList.clear();
                Storage.mvArrList.clear();
                request();
                myAdt.notifyDataSetChanged();
               Storage.year_txt_main.setText("");
               Storage.month_txt_main.setText("");
               Storage.date_txt_main.setText("");

            } else {
//                Log.d("aabb", "출력X");
                Toast.makeText(this, "날짜를 다시 입력해주세요. 2010년 이후부터 검색가능합니다.", Toast.LENGTH_SHORT).show();
            
            }


        }


    }

    class ItemHolder {

        TextView rankHolder;
        TextView nameHolder;
        TextView countHolder;
        TextView totalHolder;
    }


    class MyAdapter extends ArrayAdapter {

        LayoutInflater lnf;

        public MyAdapter(Activity context) {
            super(context, R.layout.activity_main, Storage.mvArrList);
            lnf = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return Storage.mvArrList.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return Storage.mvArrList.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            ItemHolder viewHolder;
            if (convertView == null) {

                convertView = lnf.inflate(R.layout.list_view_custom, parent, false);
                //커스텀 뷰 연결

                viewHolder = new ItemHolder();  //

                viewHolder.rankHolder = convertView.findViewById(R.id.rank_show);
                viewHolder.nameHolder = convertView.findViewById(R.id.title_text_show_list);
                viewHolder.countHolder = convertView.findViewById(R.id.count_text_show_list);
                viewHolder.totalHolder = convertView.findViewById(R.id.total_count_text_show_list);

                convertView.setTag(viewHolder);

            } else {
                viewHolder = (ItemHolder) convertView.getTag();
            }


            DecimalFormat formatter = new DecimalFormat("###,###");

            int temp_count_holder = Integer.parseInt(Storage.mvArrList.get(position).count);
            int temp_total_holder = Integer.parseInt(Storage.mvArrList.get(position).total_count);

            //커스텀뷰의 뷰들과 연결

            viewHolder.rankHolder.setText(Storage.mvArrList.get(position).rank + "위");
            viewHolder.nameHolder.setText(Storage.mvArrList.get(position).title);
//            viewHolder.countHolder.setText(Storage.mvArrList.get(position).count + "명");
//            viewHolder.totalHolder.setText(Storage.mvArrList.get(position).total_count + "명");

            viewHolder.countHolder.setText(formatter.format(temp_count_holder) + "명");
            viewHolder.totalHolder.setText(formatter.format(temp_total_holder) + "명");

            return convertView;
        }


    }


    public void request() {

        if (Integer.parseInt(Storage.month) < 10 && Integer.parseInt(Storage.month) > 0) {
            Storage.month = "0" + Storage.month;
        }


        if (Integer.parseInt(Storage.date) < 10 && Integer.parseInt(Storage.date) > 0) {
            Storage.date = "0" + Storage.date;
        }


        Storage.url = "http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?key=f0e5a0fd0c4f1b3651ed4b95f16d57dc&targetDt=";


        String temp = Storage.year + Storage.month + Storage.date;
        Storage.url = Storage.url + temp;


        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest myReq = new StringRequest(Request.Method.GET, Storage.url, successListener, errorListener);

        requestQueue.add(myReq);

        Log.d("aabb", Storage.url);
    }

    Response.Listener<String> successListener = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            try {

                Log.d("aabb", "연결완료");


                int gauge_num=10;
//                //http://jsonviewer.stack.hu/

                JSONObject firstJson = new JSONObject(response);
                JSONObject secondJson = firstJson.getJSONObject("boxOfficeResult");
                JSONArray thirdJsonArr = secondJson.getJSONArray("dailyBoxOfficeList");

                for (int i = 0; i < 10; i++) {
                    JSONObject finalJson = thirdJsonArr.getJSONObject(i);
                    Storage.mvCodeList.add(finalJson.getString("movieCd"));
//                        Log.d("aabb",finalJson.getString("movieCd"));

                    myAdt.add(new itemClass(i, finalJson.getString("movieNm"), finalJson.getString("audiCnt"), finalJson.getString("audiAcc")));
                    //어뎁터에 add를했는데 예제에서는 그냥 어레이에 add를했따. 왜 차이가발생하는가

                }

                pgBar.setVisibility(View.INVISIBLE);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
        }
    };


}

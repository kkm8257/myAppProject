package com.example.movie_app_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

public class movie_info_frame extends AppCompatActivity implements View.OnClickListener {


    String info_mvCode;


    TextView info_title_java;
    TextView info_title_eng_java;
    TextView info_level_java;
    TextView info_genre_java;
    TextView info_direc_java;
    TextView info_runtime_java;
    TextView info_audiCnt_java;
    TextView info_openDate_java;
    TextView info_audiCnt_total_java;
    TextView info_actor_java;

    Button backBtn;

    String movieName;
    String movieName_eng;
    String watchGrade;
    String showTm;
    String openDt;
    String genre;

    String direc;
    String audi_count;
    String audi_total;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_info_frame);

        info_mvCode = Storage.mvCodeList.get(Storage.position);  //누른 영화의 순번을 가져다가 영화코드값 받기

        backBtn=findViewById(R.id.back_btn);

        backBtn.setOnClickListener(this);

        info_title_java = findViewById(R.id.info_title);
        info_title_eng_java = findViewById(R.id.info_title_eng);
        info_level_java = findViewById(R.id.info_level_show);
        info_genre_java = findViewById(R.id.info_genre_show);
        info_direc_java = findViewById(R.id.info_direct_show);
        info_runtime_java = findViewById(R.id.info_runtime_show);
        info_audiCnt_java = findViewById(R.id.info_audiCnt_show);
        info_openDate_java = findViewById(R.id.info_openDate_show);
        info_audiCnt_total_java = findViewById(R.id.info_audiCnt_total_show);
        info_actor_java = findViewById(R.id.info_actor_show);


        info_request();

    }

    public void info_request() {


        Storage.url = "http://www.kobis.or.kr/kobisopenapi/webservice/rest/movie/searchMovieInfo.json?key=f0e5a0fd0c4f1b3651ed4b95f16d57dc&movieCd=";


        Storage.url = Storage.url + Storage.mvCodeList.get(Storage.position);


        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest myReq = new StringRequest(Request.Method.GET, Storage.url, successListener, errorListener);

        requestQueue.add(myReq);

        Log.d("aabb", Storage.url);
    }

    Response.Listener<String> successListener = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            try {


                JSONObject firstJson = new JSONObject(response);
                JSONObject secondJson = firstJson.getJSONObject("movieInfoResult");
                JSONObject thirdJson = secondJson.getJSONObject("movieInfo");

                movieName = thirdJson.getString("movieNm");
                info_title_java.setText(movieName);
//
                movieName_eng = thirdJson.getString("movieNmEn");
                info_title_eng_java.setText(movieName_eng);
//
                JSONArray checkGradeJsonArr = thirdJson.getJSONArray("audits");
                JSONObject checkGradeJsonObj = checkGradeJsonArr.getJSONObject(0);

//
                watchGrade = checkGradeJsonObj.getString("watchGradeNm");
                info_level_java.setText(watchGrade);
//
//
                showTm = thirdJson.getString("showTm");
                openDt = thirdJson.getString("openDt");

                info_runtime_java.setText(showTm + " 분");


                String temp_year;
                String temp_month;
                String temp_date;

                temp_year = openDt.substring(0, 4);
                if (openDt.substring(4, 6).equals("10") || openDt.substring(4, 6).equals("11") || openDt.substring(4, 6).equals("12")) {

                    temp_month = openDt.substring(4, 6);
                } else {
                    temp_month = openDt.substring(5, 6);
                }

                if(openDt.substring(6,8).equals("01")||openDt.substring(6,8).equals("02")||openDt.substring(6,8).equals("03")||openDt.substring(6,8).equals("04")||openDt.substring(6,8).equals("05")||openDt.substring(6,8).equals("06")||openDt.substring(6,8).equals("07")||openDt.substring(6,8).equals("08")||openDt.substring(6,8).equals("09")){
                    temp_date=openDt.substring(7,8);

                }
                else{
                    temp_date=openDt.substring(6,8);
                }
                info_openDate_java.setText(temp_year+"년 "+temp_month+"월 "+temp_date+"일");

//
                JSONArray checkGenreJsonArr = thirdJson.getJSONArray("genres");
                JSONObject checkGenreJsonObj = checkGenreJsonArr.getJSONObject(0);
//
                genre = checkGenreJsonObj.getString("genreNm");
                info_genre_java.setText(genre);
//

                JSONArray checkDirecJsonArr = thirdJson.getJSONArray("directors");
                JSONObject checkDrectJsonObj = checkDirecJsonArr.getJSONObject(0);
                direc = checkDrectJsonObj.getString("peopleNm");
                info_direc_java.setText(direc);
                //


                DecimalFormat formatter = new DecimalFormat("###,###");

                int temp_count_holder=Integer.parseInt(Storage.mvArrList.get(Storage.position).count);
                int temp_total_holder=Integer.parseInt(Storage.mvArrList.get(Storage.position).total_count);





                audi_count = formatter.format(temp_count_holder);
                info_audiCnt_java.setText(audi_count + " 명");
                audi_total = formatter.format(temp_total_holder);
                info_audiCnt_total_java.setText(audi_total + " 명");


                String actorList="";

                JSONArray checkActorsJsonArr= thirdJson.getJSONArray("actors");

                for(int i =0; i <checkActorsJsonArr.length();i++){

                    JSONObject actorObj=checkActorsJsonArr.getJSONObject(i);
                    if(i==checkActorsJsonArr.length()-1){

                        actorList=actorList+actorObj.getString("peopleNm");
                    }
                    else{

                        actorList=actorList+actorObj.getString("peopleNm")+", ";
                    }


                }

                info_actor_java.setText(actorList);


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
        }
    };

    @Override
    public void onClick(View view) {

        if(view.getId()==R.id.back_btn){

            finish();

        }

    }
}

package com.example.movie_app_2;

import android.content.Intent;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Storage {

public static int position ;

    public static boolean isFirst=true;

    public static TextView year_txt_main;
    public static TextView month_txt_main;
    public static TextView date_txt_main;

    public static Button click_btn;

    public static String year;
    public static String month;
    public static String date;

    public static ListView listView;

    public static ArrayList<itemClass> mvArrList=new ArrayList<>();

    public static ArrayList<String> mvCodeList=new ArrayList<>();

    public static String url;




}

package com.example.gridview;

public class toDo_ItemData {

    int idx;
    int year;
    int month;
    int date;

    String content;

    public toDo_ItemData(int idx,int year, int month, int date, String content) {
        this.idx= idx;
        this.year = year;
        this.month = month;
        this.date = date;
        this.content = content;
    }
}

package com.example.gridview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    GridView gv;
    MyAdapter adt;
    ArrayList<ItemData> arr = new ArrayList<>();


    int nowLastCode;
    int nowLast;
    int preLastCode;
    int preLast;


    public toDo_ItemData tempDialItem;

    ArrayList<toDo_ItemData> arrTodoArr = new ArrayList<>();
    dial_Adapter dial_adt;
    ListView lv;


    Button deleteBtn;
    TextView toDolist_tv;

    EditText writeTodo_et;
    Button input_btn;


    TextView month_tv;

    Calendar now_cal;
    int year;
    int month;

    String sql = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final SQLiteDatabase db = openOrCreateDatabase("aakk.db", Context.MODE_PRIVATE, null);  //밖에다 못두는 이유가 상속보다 먼저 전역변수가 쭈욱 생성되는데, sql라이트는 자바의 기본 기능이아니라서;에러가 빵터짐

        db.execSQL("CREATE TABLE IF NOT EXISTS Mycalendar("
                + "idx INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "year INTEGER,"
                + "month INTEGER,"
                + "date INTEGER,"
                + "content TEXT" + ");");

        gv = findViewById(R.id.gv);
        adt = new MyAdapter(this);
        gv.setAdapter(adt);


        month_tv = findViewById(R.id.month_tv);
        now_cal = Calendar.getInstance(); //현재날짜 세팅
        year = now_cal.get(Calendar.YEAR); //현재날짜 연도
        month = now_cal.get(Calendar.MONTH); //현재날짜 월

        Log.d("aabb", "최초월 : " + (now_cal.get(Calendar.MONTH) + 1));

        month_tv.setText((now_cal.get(Calendar.MONTH) + 1) + "월");

        makeCal();

        findViewById(R.id.ex_month_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adt.clear();
                now_cal.add(Calendar.MONTH, -1);
                makeCal();
            }
        });

        findViewById(R.id.next_month_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adt.clear();
                now_cal.add(Calendar.MONTH, 1);

                makeCal();

            }
        });


        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                final SQLiteDatabase db = openOrCreateDatabase("aakk.db", Context.MODE_PRIVATE, null);  //밖에다 못두는 이유가 상속보다 먼저 전역변수가 쭈욱 생성되는데, sql라이트는 자바의 기본 기능이아니라서;에러가 빵터짐

                if (position >= 7) {


                    final int tempyear = year;
                    final int tempmonth;
                    final int tempdate = Integer.parseInt(arr.get(position).str);

                    LayoutInflater inflater = getLayoutInflater();
                    View dialog_View = inflater.inflate(R.layout.activity_todo_list, null);
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this); //AlertDialog.Builder 객체 생성

                    if (position - 6 - preLastCode > 0 && position - 6 - preLastCode <= nowLast) {

                        builder.setTitle(year + "." + (month + 1) + "." + arr.get(position).str);
                        tempmonth = month + 1;
                    } else if (position - 7 < preLastCode) {
                        builder.setTitle(year + "." + month + "." + arr.get(position).str);
                        tempmonth = month;
                    }  //43
                    else {
                        builder.setTitle(year + "." + (month + 2) + "." + arr.get(position).str);
                        tempmonth = month + 2;
                    }


                    builder.setView(dialog_View); // 세팅
                    final AlertDialog dialog = builder.create();

                    lv = dialog_View.findViewById(R.id.list_lv);   //실제로는 없는데? 이렇게 플레터를 통해 연결하여 사용가능 . 해당 xml에 연결된 자바와는 무관   why? intent로 액티비티가 시작되는게 아니기떄문! onCreate가 안댐
                    dial_adt = new dial_Adapter(MainActivity.this);
                    lv.setAdapter(dial_adt);

                    toDolist_tv = dialog_View.findViewById(R.id.content_tv);
                    deleteBtn = dialog_View.findViewById(R.id.delete_btn);

                    writeTodo_et = dialog_View.findViewById(R.id.write_et);
                    input_btn = dialog_View.findViewById(R.id.input_btn);

                    dial_adt.clear();
                    Cursor c = db.rawQuery("SELECT * FROM Mycalendar WHERE year = " + tempyear + " AND month = " + tempmonth + " AND date=" + tempdate + "", null);
                    c.moveToFirst();

                    while (c.isAfterLast() == false) {
                        Log.d("aabb",
                                "idx : " + c.getInt(0) + " y: " + c.getInt(1)
                                        + " m: " + c.getInt(2)
                                        + " d: " + c.getInt(3)
                                        + "con : " + c.getString(4));

                        if (c.getInt(1) == tempyear && c.getInt(2) == tempmonth && c.getInt(3) == tempdate) {

                            dial_adt.add(new toDo_ItemData(c.getInt(0), tempyear, tempmonth, tempdate, c.getString(4)));
                            Log.d("aabb", "-->>" + c.getInt(0));

                        }

                        c.moveToNext();
                    }

                    c.close();

                    input_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            SQLiteDatabase db = openOrCreateDatabase("aakk.db", Context.MODE_PRIVATE, null);
                            dial_adt.clear();
                            String tempStr = writeTodo_et.getText().toString();
//                            dial_adt.add(new toDo_ItemData(temp));
                            Log.d("aabb", tempyear + "");
                            Log.d("aabb", tempmonth + "");
                            Log.d("aabb", tempdate + "");
                            Log.d("aabb", tempStr);
                            sql = "INSERT INTO Mycalendar (year,month,date,content) VALUES ('" + tempyear + "','" + tempmonth + "','" + tempdate + "','" + tempStr + "')";
                            db.execSQL(sql);

                            writeTodo_et.setText("");
                            Cursor c = db.rawQuery("SELECT * FROM Mycalendar WHERE year = " + tempyear + " AND month = " + tempmonth + " AND date=" + tempdate + "", null);
                            c.moveToFirst();

                            while (c.isAfterLast() == false) {
                                Log.d("aabb",
                                        "idx : " + c.getInt(0) + " y: " + c.getInt(1)
                                                + " m: " + c.getInt(2)
                                                + " d: " + c.getInt(3)
                                                + "con : " + c.getString(4));

                                if (c.getInt(1) == tempyear && c.getInt(2) == tempmonth && c.getInt(3) == tempdate) {

                                    dial_adt.add(new toDo_ItemData(c.getInt(0), tempyear, tempmonth, tempdate, c.getString(4)));

                                }

                                c.moveToNext();
                            }

                            c.close();


                            dial_adt.notifyDataSetChanged();
                        }
                    });

                    dialog.show();
                }


            }
        });


    }

    public void makeCal() {
        adt.add(new ItemData("일", "blue", 30));
        adt.add(new ItemData("월", "blue", 30));
        adt.add(new ItemData("화", "blue", 30));
        adt.add(new ItemData("수", "blue", 30));
        adt.add(new ItemData("목", "blue", 30));
        adt.add(new ItemData("금", "blue", 30));
        adt.add(new ItemData("토", "blue", 30));

        month_tv.setText((now_cal.get(Calendar.MONTH) + 1) + "월");

//        Log.d("aabb", "현재월 : " + (now_cal.get(Calendar.MONTH) + 1) + "월");


        now_cal.add(Calendar.MONTH, -1);
//        Log.d("aabb", "이전달" + (now_cal.get(Calendar.MONTH) + 1) + "월");

        preLast = now_cal.getActualMaximum(Calendar.DATE);
//        Log.d("aabb", "마지막 일" + preLast);

        now_cal.set(Calendar.DATE, preLast);
//        Log.d("aabb", "code" + now_cal.get(Calendar.DAY_OF_WEEK));
        preLastCode = now_cal.get(Calendar.DAY_OF_WEEK);
        Log.d("aabb", "저번달 : " + preLastCode);


        for (int i = preLastCode - 1; i >= 0; i--) {
            adt.add(new ItemData(Integer.toString(preLast - i), "gray", 17));

        }

        now_cal.add(Calendar.MONTH, 1);//현재월로 복귀
        nowLast = now_cal.getActualMaximum(Calendar.DATE);
        now_cal.set(Calendar.DATE, nowLast);
        nowLastCode = now_cal.get(Calendar.DAY_OF_WEEK); //이번달 마지막 날 코드저장
        Log.d("aabb", "이번달 : " + nowLastCode);


        for (int i = 1; i <= nowLast; i++) {
            adt.add(new ItemData(Integer.toString(i), "black", 20));
        }

        now_cal.add(Calendar.MONTH, 1);//다음달 전진
        now_cal.set(Calendar.DATE, 1);
        int nextFirst = now_cal.get(Calendar.DAY_OF_WEEK);

        for (int i = 1; i <= 8 - nextFirst; i++) {
            adt.add(new ItemData(Integer.toString(i), "gray", 17));
        }

        now_cal.add(Calendar.MONTH, -1);

        year = now_cal.get(Calendar.YEAR);
        month = now_cal.get(Calendar.MONTH);

        adt.notifyDataSetChanged();
    }

    class ItemHolder {
        TextView tvHolder;
    }

    class MyAdapter extends ArrayAdapter {
        LayoutInflater lnf;

        public MyAdapter(Activity context) {
            super(context, R.layout.item, arr);
            lnf = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return arr.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return arr.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            ItemHolder viewHolder;
            if (convertView == null) {

                convertView = lnf.inflate(R.layout.item, parent, false);
                viewHolder = new ItemHolder();

                viewHolder.tvHolder = convertView.findViewById(R.id.tv);

                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ItemHolder) convertView.getTag();
            }

            viewHolder.tvHolder.setText(arr.get(position).str);
            viewHolder.tvHolder.setTextSize(arr.get(position).size);


            if (arr.get(position).color.equals("blue")) {
                viewHolder.tvHolder.setTextColor(Color.BLUE);
            } else if (arr.get(position).color.equals("black")) {
                viewHolder.tvHolder.setTextColor(Color.BLACK);
            } else if (arr.get(position).color.equals("gray")) {
                viewHolder.tvHolder.setTextColor(Color.GRAY);
            }

            if (position % 7 == 0) {
                viewHolder.tvHolder.setTextColor(Color.RED);
            }
            return convertView;
        }
    }


    class toDoItemHolder {
        int idx;
        TextView tvHolder;
        Button delButton;
    }

    class dial_Adapter extends ArrayAdapter {
        LayoutInflater lnf;

        public dial_Adapter(Activity context) {
            super(context, R.layout.todo_item, arrTodoArr);
            lnf = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return arrTodoArr.size();
        }

        @Override
        public toDo_ItemData getItem(int position) {
            // TODO Auto-generated method stub
            return arrTodoArr.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        public View getView(final int position, View convertView, ViewGroup parent) {
            final toDoItemHolder viewHolder;
            final SQLiteDatabase db = openOrCreateDatabase("aakk.db", Context.MODE_PRIVATE, null);  //밖에다 못두는 이유가 상속보다 먼저 전역변수가 쭈욱 생성되는데, sql라이트는 자바의 기본 기능이아니라서;에러가 빵터짐

            if (convertView == null) {


                convertView = lnf.inflate(R.layout.todo_item, parent, false);
                viewHolder = new toDoItemHolder();

//                viewHolder.idx=
                //Cursor c 이용해서 idx 담아야할듯

                viewHolder.tvHolder = convertView.findViewById(R.id.content_tv);
                viewHolder.delButton = convertView.findViewById(R.id.delete_btn);


                convertView.setTag(viewHolder);

//                db.execSQL(sql);

            } else {
                viewHolder = (toDoItemHolder) convertView.getTag();
            }

            viewHolder.idx=arrTodoArr.get(position).idx;
            viewHolder.delButton.setTag(position);
            viewHolder.tvHolder.setText(arrTodoArr.get(position).content);

            viewHolder.delButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sql = "DELETE FROM Mycalendar WHERE idx='" + viewHolder.idx + "'";
                    db.execSQL(sql);
                    int tempyear=arrTodoArr.get(position).year;
                    int tempmonth=arrTodoArr.get(position).month;
                    int tempdate=arrTodoArr.get(position).date;
                    dial_adt.clear();

                    Cursor c = db.rawQuery("SELECT * FROM Mycalendar WHERE year = " + tempyear + " AND month = " + tempmonth + " AND date=" + tempdate + "", null);
                    c.moveToFirst();

                    while (c.isAfterLast() == false) {
                        Log.d("aabb",
                                "idx : "+c.getInt(0)+" y: " + c.getInt(1)
                                        + " m: " + c.getInt(2)
                                        + " d: " + c.getInt(3)
                                        + "con : " + c.getString(4));

                        if (c.getInt(1) == tempyear && c.getInt(2) == tempmonth && c.getInt(3) == tempdate) {

                            dial_adt.add(new toDo_ItemData(c.getInt(0),tempyear, tempmonth, tempdate,c.getString(4) ));

                        }

                        c.moveToNext();
                    }

                    c.close();
                    dial_adt.notifyDataSetChanged();

                }
            });

            return convertView;
        }
    }


}
package com.example.gridview;

public class ItemData {


    String str;
    String color;
    int size;

    public ItemData(String str,String color,int size) {

        this.str = str;
        this.color=color;
        this.size=size;
    }

}
